"use client";

import { useEffect, useState } from "react";
import "../admin.css";

export default function AdminUsersPage() {
  const [token, setToken] = useState("");
  const [users, setUsers] = useState<unknown[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const t = localStorage.getItem("assessor_admin_token") || "";
    setToken(t);
    if (!t) return;
    fetch("/api/admin/users", { headers: { Authorization: `Bearer ${t}` } })
      .then(async (r) => {
        if (!r.ok) throw new Error("forbidden");
        return r.json();
      })
      .then((d) => setUsers(d.users || []))
      .catch(() => setError("Sem permissão"));
  }, []);

  if (!token) {
    return (
      <div className="login-wrap">
        <div className="login-card">
          <p>
            <a href="/admin">Faça login no Admin</a>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-shell">
      <header className="admin-top">
        <div>
          <h1 className="admin-brand">Usuários</h1>
          <p className="admin-sub">Visão operacional (sem conteúdo privado)</p>
        </div>
        <nav className="admin-nav">
          <a href="/admin">Dashboard</a>
          <a href="/admin/users" aria-current="page">
            Usuários
          </a>
          <a href="/admin/jobs">Jobs</a>
          <a href="/admin/templates">Templates</a>
        </nav>
      </header>
      {error && <p className="toast err">{error}</p>}
      <section className="admin-card">
        <pre style={{ whiteSpace: "pre-wrap", fontSize: 12, margin: 0 }}>
          {JSON.stringify(users, null, 2)}
        </pre>
      </section>
    </div>
  );
}
