"use client";

import { useEffect, useMemo, useState } from "react";
import "./admin.css";

type Dash = {
  metrics: Record<string, number>;
  status: Record<string, string>;
  webhook_url: string;
};

type ZernioNumber = {
  account_id: string;
  profile_id: string;
  phone: string;
  name: string;
  label: string;
};

type ProviderRow = {
  provider_key: string;
  enabled: boolean;
  config?: Record<string, unknown>;
  secrets?: Record<string, string>;
  last_test_status?: string;
};

function statusTone(v: string) {
  const s = String(v || "").toUpperCase();
  if (s.includes("ONLINE") || s.includes("CONNECTED")) return "ok";
  if (s.includes("OFFLINE") || s.includes("NOT_CONFIGURED")) return "warn";
  if (s.includes("ERROR")) return "err";
  return "";
}

export default function AdminPage() {
  const [token, setToken] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [dash, setDash] = useState<Dash | null>(null);
  const [providers, setProviders] = useState<ProviderRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const [apiKey, setApiKey] = useState("");
  const [webhookSecret, setWebhookSecret] = useState("");
  const [numbers, setNumbers] = useState<ZernioNumber[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [listing, setListing] = useState(false);
  const [savingZernio, setSavingZernio] = useState(false);

  const [openaiKey, setOpenaiKey] = useState("");
  const [savingOpenAI, setSavingOpenAI] = useState(false);
  const [emailForm, setEmailForm] = useState({
    base_url: "https://mailserver.moope.com.br",
    api_key: "",
    from_address: "info@info.moope.com.br",
    from_name: "MOOPE Meu Assessor",
    test_to: "",
  });
  const [savingEmail, setSavingEmail] = useState(false);

  const zernioProvider = useMemo(
    () => providers.find((p) => p.provider_key === "zernio"),
    [providers]
  );

  const selectedNumber = numbers.find((n) => n.account_id === selectedId);
  const savedPhone = String(zernioProvider?.config?.official_number || "");
  const savedAccount = String(zernioProvider?.config?.account_id || "");
  const hasSavedKey = Boolean(zernioProvider?.secrets?.api_key);

  const zernioStep = !hasSavedKey && !apiKey
    ? 1
    : numbers.length === 0
      ? 2
      : selectedId
        ? 3
        : 2;

  async function login() {
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "login_failed");
        return;
      }
      const tok = data.access_token as string;
      setToken(tok);
      localStorage.setItem("assessor_admin_token", tok);
      await load(tok);
    } catch {
      setError("Falha de rede ao entrar");
    } finally {
      setLoading(false);
    }
  }

  async function load(tok = token) {
    if (!tok) return;
    const headers = { Authorization: `Bearer ${tok}` };
    const d = await fetch("/api/admin/dashboard", { headers });
    if (d.status === 403 || d.status === 401) {
      setError("Sem permissão de platform_admin");
      setDash(null);
      setToken("");
      localStorage.removeItem("assessor_admin_token");
      return;
    }
    if (!d.ok) {
      setError(`Falha ao carregar dashboard (${d.status})`);
      return;
    }
    setDash(await d.json());
    const p = await fetch("/api/admin/providers", { headers });
    const pj = await p.json();
    const list = (pj.providers || []) as ProviderRow[];
    setProviders(list);
    const z = list.find((x) => x.provider_key === "zernio");
    if (z?.config?.account_id) {
      setSelectedId(String(z.config.account_id));
    }
    const em = list.find((x) => x.provider_key === "email");
    if (em?.config) {
      setEmailForm((prev) => ({
        ...prev,
        base_url: String(em.config?.base_url || prev.base_url),
        from_address: String(em.config?.from_address || prev.from_address),
        from_name: String(em.config?.from_name || prev.from_name),
      }));
    }
  }

  useEffect(() => {
    const t = localStorage.getItem("assessor_admin_token") || "";
    if (t) {
      setToken(t);
      void load(t);
    }
  }, []);

  async function buscarNumeros() {
    setListing(true);
    setMsg("");
    setError(null);
    try {
      const res = await fetch("/api/admin/providers/zernio/numbers", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          api_key: apiKey || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.message || data.error || "Falha ao listar números");
        setNumbers([]);
        return;
      }
      const lista = (data.numbers || []) as ZernioNumber[];
      setNumbers(lista);
      if (lista.length === 1) {
        setSelectedId(lista[0].account_id);
      } else if (data.selected_account_id) {
        setSelectedId(String(data.selected_account_id));
      }
      if (!lista.length) {
        setMsg(
          "Essa chave não tem WhatsApp em Connections. Conecte um número na Zernio."
        );
      } else {
        setMsg(
          lista.length === 1
            ? `Número encontrado: ${lista[0].label}`
            : `${lista.length} números encontrados — escolha qual a plataforma vai usar.`
        );
      }
    } catch {
      setError("Falha de rede ao buscar números");
    } finally {
      setListing(false);
    }
  }

  async function salvarZernio() {
    if (!selectedId) {
      setError("Escolha o número oficial antes de salvar.");
      return;
    }
    const hit = numbers.find((n) => n.account_id === selectedId);
    setSavingZernio(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/providers/zernio/numbers", {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          api_key: apiKey || undefined,
          webhook_secret: webhookSecret || undefined,
          account_id: selectedId,
          phone: hit?.phone || savedPhone,
          profile_id: hit?.profile_id,
          name: hit?.name,
          enabled: true,
        }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error || "Falha ao salvar Zernio");
        return;
      }
      setApiKey("");
      setWebhookSecret("");
      setMsg("Zernio salva — número oficial configurado.");
      await load();
      const test = await fetch("/api/admin/providers", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ provider_key: "zernio" }),
      });
      const tj = await test.json();
      setMsg(`Zernio salva · teste: ${tj.status}`);
      await load();
    } finally {
      setSavingZernio(false);
    }
  }

  async function saveOpenAI() {
    if (!openaiKey.trim()) {
      setError("Cole a API Key da OpenAI antes de salvar.");
      setMsg("");
      return;
    }
    setSavingOpenAI(true);
    setError(null);
    setMsg("");
    try {
      const headers = {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      };
      const targets = [
        {
          provider_key: "openai_llm",
          config: { model: "gpt-4o-mini" },
        },
        {
          provider_key: "openai_embeddings",
          config: { model: "text-embedding-3-small", dimensions: 1536 },
        },
        { provider_key: "vision", config: {} },
        { provider_key: "transcription", config: {} },
      ] as const;

      for (const t of targets) {
        const res = await fetch("/api/admin/providers", {
          method: "PUT",
          headers,
          body: JSON.stringify({
            provider_key: t.provider_key,
            enabled: true,
            provider_name: "openai",
            config: t.config,
            secrets: { api_key: openaiKey.trim() },
          }),
        });
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          setError(
            `Falha ao salvar ${t.provider_key}: ${data.error || res.status}`
          );
          return;
        }
      }

      const test = await fetch("/api/admin/providers", {
        method: "POST",
        headers,
        body: JSON.stringify({ provider_key: "openai_llm" }),
      });
      const tj = await test.json();
      setOpenaiKey("");
      setMsg(
        `OpenAI salva no banco (criptografada). Teste: ${tj.status || "ok"}`
      );
      await load();
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setError("Falha de rede ao salvar OpenAI");
    } finally {
      setSavingOpenAI(false);
    }
  }

  async function testOpenAI() {
    setMsg("");
    setError(null);
    const res = await fetch("/api/admin/providers", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ provider_key: "openai_llm" }),
    });
    const data = await res.json();
    setMsg(`OpenAI test: ${data.status}`);
    window.scrollTo({ top: 0, behavior: "smooth" });
    await load();
  }

  async function saveEmail() {
    setSavingEmail(true);
    setError(null);
    setMsg("");
    try {
      const res = await fetch("/api/admin/providers", {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          provider_key: "email",
          enabled: true,
          provider_name: "mailserver",
          config: {
            provider: "mailserver",
            base_url: emailForm.base_url,
            from_name: emailForm.from_name,
            from_address: emailForm.from_address,
          },
          secrets: { api_key: emailForm.api_key || undefined },
        }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error || "Falha ao salvar email");
        return;
      }
      setEmailForm({ ...emailForm, api_key: "" });
      setMsg("Mailserver salvo no banco (API key criptografada).");
      window.scrollTo({ top: 0, behavior: "smooth" });
      await load();
    } catch {
      setError("Falha de rede ao salvar email");
    } finally {
      setSavingEmail(false);
    }
  }

  async function testEmail() {
    setMsg("");
    setError(null);
    const res = await fetch("/api/admin/providers", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        provider_key: "email",
        to: emailForm.test_to || email,
      }),
    });
    const data = await res.json();
    setMsg(
      `Email test: ${data.status}${data.via ? ` via ${data.via}` : ""}`
    );
    window.scrollTo({ top: 0, behavior: "smooth" });
    await load();
  }

  function logout() {
    localStorage.removeItem("assessor_admin_token");
    setToken("");
    setDash(null);
  }

  if (!token || !dash) {
    return (
      <div className="login-wrap">
        <div className="login-card">
          <h1>MOOPE Meu Assessor</h1>
          <p className="admin-sub">Área interna da plataforma</p>
          {error && <p className="toast err">{error}</p>}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void login();
            }}
            style={{ marginTop: "1.1rem" }}
          >
            <div className="field">
              <label>E-mail</label>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="username"
                placeholder="admin@moope.com.br"
              />
            </div>
            <div className="field">
              <label>Senha</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
              />
            </div>
            <button className="btn" type="submit" disabled={loading}>
              {loading ? "Entrando…" : "Entrar"}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-shell">
      <header className="admin-top">
        <div>
          <h1 className="admin-brand">Admin operacional</h1>
          <p className="admin-sub">Configure providers e acompanhe a saúde do Assessor</p>
        </div>
        <nav className="admin-nav">
          <a href="/admin" aria-current="page">
            Dashboard
          </a>
          <a href="/admin/users">Usuários</a>
          <a href="/admin/jobs">Jobs</a>
          <a href="/admin/templates">Templates</a>
          <button type="button" onClick={logout}>
            Sair
          </button>
        </nav>
      </header>

      {msg && (
        <p className="toast" style={{ position: "sticky", top: 8, zIndex: 20 }}>
          {msg}
        </p>
      )}
      {error && (
        <p
          className="toast err"
          style={{ position: "sticky", top: 8, zIndex: 20 }}
        >
          {error}
        </p>
      )}

      <section className="admin-card" style={{ marginBottom: "1rem" }}>
        <h2>Saúde</h2>
        <p className="hint">Status cacheado — testes pagos só quando você clicar em Testar.</p>
        <div className="status-row">
          {Object.entries(dash.status).map(([k, v]) => (
            <div key={k} className={`status-pill ${statusTone(v)}`}>
              <span className="k">{k}</span>
              <span className="v">{v}</span>
            </div>
          ))}
        </div>
        <div className="metric-grid" style={{ marginTop: "0.9rem" }}>
          {Object.entries(dash.metrics || {}).map(([k, v]) => (
            <div key={k} className="metric">
              <b>{String(v)}</b>
              <small>{k.replace(/_/g, " ")}</small>
            </div>
          ))}
        </div>
      </section>

      <div className="admin-grid two">
        <section className="admin-card">
          <h2>WhatsApp / Zernio</h2>
          <p className="hint">
            Igual ao MOOPE Finance: cole só a API Key, busque os números da conta e
            escolha o número oficial da plataforma.
          </p>

          <div className="steps">
            <span className={`step ${zernioStep >= 1 ? "on" : ""}`}>1. API Key</span>
            <span className={`step ${zernioStep >= 2 ? "on" : ""}`}>2. Números</span>
            <span className={`step ${zernioStep >= 3 ? "on" : ""}`}>3. Escolher</span>
          </div>

          {(savedPhone || savedAccount) && (
            <div className="webhook-box" style={{ marginBottom: "0.9rem" }}>
              <strong>Número oficial atual</strong>
              <div>{savedPhone || "—"}</div>
              <div style={{ opacity: 0.7, marginTop: 4 }}>
                Account: {savedAccount || "—"}
              </div>
              <div style={{ opacity: 0.7 }}>
                Status: {zernioProvider?.last_test_status || "never"}
              </div>
            </div>
          )}

          <div className="field">
            <label>API Key {hasSavedKey ? "(•••• já salva — cole outra para trocar)" : ""}</label>
            <input
              type="password"
              placeholder={hasSavedKey ? "••••••••••" : "sk_…"}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              autoComplete="off"
            />
          </div>

          <div className="btn-row">
            <button
              className="btn"
              type="button"
              disabled={listing || (!apiKey && !hasSavedKey)}
              onClick={() => void buscarNumeros()}
            >
              {listing ? "Buscando…" : "Buscar números"}
            </button>
          </div>

          {numbers.length === 1 && (
            <div className="webhook-box">
              Número encontrado: <strong>{numbers[0].label}</strong>
            </div>
          )}

          {numbers.length > 1 && (
            <div className="number-list" role="radiogroup" aria-label="Números Zernio">
              {numbers.map((n) => (
                <label
                  key={n.account_id}
                  className={`number-option ${selectedId === n.account_id ? "selected" : ""}`}
                >
                  <input
                    type="radio"
                    name="zernio_numero"
                    checked={selectedId === n.account_id}
                    onChange={() => setSelectedId(n.account_id)}
                  />
                  <div>
                    <strong>{n.label}</strong>
                    {n.name && n.phone && <span>{n.name}</span>}
                    <span>ID …{n.account_id.slice(-6)}</span>
                  </div>
                </label>
              ))}
            </div>
          )}

          {numbers.length === 0 && hasSavedKey && (
            <p className="hint">Clique em Buscar números para carregar da Zernio.</p>
          )}

          <details className="advanced">
            <summary>Avançado (webhook secret)</summary>
            <div className="field" style={{ marginTop: "0.75rem" }}>
              <label>Webhook Secret</label>
              <input
                type="password"
                placeholder="opcional — se a Zernio exigir"
                value={webhookSecret}
                onChange={(e) => setWebhookSecret(e.target.value)}
              />
            </div>
          </details>

          <div className="webhook-box">
            <strong>Webhook URL</strong>
            <div>{dash.webhook_url}</div>
            <div style={{ opacity: 0.7, marginTop: 6 }}>
              Configure esta URL nas Connections da Zernio.
            </div>
          </div>

          <div className="btn-row">
            <button
              className="btn"
              type="button"
              disabled={savingZernio || !selectedId}
              onClick={() => void salvarZernio()}
            >
              {savingZernio ? "Salvando…" : "Salvar número oficial"}
            </button>
            {selectedNumber && (
              <span className="admin-sub" style={{ alignSelf: "center" }}>
                Selecionado: {selectedNumber.label}
              </span>
            )}
          </div>
        </section>

        <div className="admin-grid">
          <section className="admin-card">
            <h2>Inteligência Artificial</h2>
            <p className="hint">
              Uma chave OpenAI para LLM, embeddings, vision e áudio. Salva
              criptografada no banco (não fica em plaintext).
            </p>
            {providers.some(
              (p) => p.provider_key === "openai_llm" && p.secrets?.api_key
            ) && (
              <div className="webhook-box" style={{ marginBottom: 12 }}>
                Chave já salva · status:{" "}
                {providers.find((p) => p.provider_key === "openai_llm")
                  ?.last_test_status || "never"}
              </div>
            )}
            <div className="field">
              <label>API Key</label>
              <input
                type="password"
                placeholder="sk-…"
                value={openaiKey}
                onChange={(e) => setOpenaiKey(e.target.value)}
              />
            </div>
            <div className="btn-row">
              <button
                className="btn"
                type="button"
                disabled={savingOpenAI}
                onClick={() => void saveOpenAI()}
              >
                {savingOpenAI ? "Salvando…" : "Salvar"}
              </button>
              <button
                className="btn secondary"
                type="button"
                onClick={() => void testOpenAI()}
              >
                Testar
              </button>
            </div>
          </section>

          <section className="admin-card">
            <h2>E-mail (mailserver MOOPE)</h2>
            <p className="hint">
              Mesmo mailserver do Finance:{" "}
              <code>https://mailserver.moope.com.br</code> com{" "}
              <code>x-api-key</code>.
            </p>
            {providers.some(
              (p) => p.provider_key === "email" && p.secrets?.api_key
            ) && (
              <div className="webhook-box" style={{ marginBottom: 12 }}>
                Mailserver já configurado · status:{" "}
                {providers.find((p) => p.provider_key === "email")
                  ?.last_test_status || "never"}
              </div>
            )}
            <div className="field">
              <label>URL</label>
              <input
                value={emailForm.base_url}
                onChange={(e) =>
                  setEmailForm({ ...emailForm, base_url: e.target.value })
                }
              />
            </div>
            <div className="field">
              <label>API Key (x-api-key)</label>
              <input
                type="password"
                placeholder="•••• se já salva"
                value={emailForm.api_key}
                onChange={(e) =>
                  setEmailForm({ ...emailForm, api_key: e.target.value })
                }
              />
            </div>
            <div className="field">
              <label>From</label>
              <input
                value={emailForm.from_address}
                onChange={(e) =>
                  setEmailForm({ ...emailForm, from_address: e.target.value })
                }
              />
            </div>
            <div className="field">
              <label>From name</label>
              <input
                value={emailForm.from_name}
                onChange={(e) =>
                  setEmailForm({ ...emailForm, from_name: e.target.value })
                }
              />
            </div>
            <div className="field">
              <label>Destinatário do teste</label>
              <input
                value={emailForm.test_to}
                onChange={(e) =>
                  setEmailForm({ ...emailForm, test_to: e.target.value })
                }
                placeholder="seu@email.com"
              />
            </div>
            <div className="btn-row">
              <button
                className="btn"
                type="button"
                disabled={savingEmail}
                onClick={() => void saveEmail()}
              >
                {savingEmail ? "Salvando…" : "Salvar"}
              </button>
              <button
                className="btn secondary"
                type="button"
                onClick={() => void testEmail()}
              >
                Testar envio
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
